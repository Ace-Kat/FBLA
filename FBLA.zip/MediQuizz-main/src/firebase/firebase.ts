import { initializeApp, getApp, getApps, FirebaseApp } from "firebase/app";
import { getAuth, Auth } from "firebase/auth";
import { getFirestore, Firestore } from "firebase/firestore";

// Explicitly define the shape of your configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string,
};

// FirebaseApp type ensures the app variable is correctly typed
const app: FirebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Typing for auth and firestore ensures proper type inference
const auth: Auth = getAuth(app);
const firestore: Firestore = getFirestore(app);

export { auth, firestore, app };
